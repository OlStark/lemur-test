import "./App.scss";
import Form from "./components/form/Form";

function App() {
  return (
    <div className="App">
      <Form />
    </div>
  );
}

export default App;
